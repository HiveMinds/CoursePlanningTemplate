# Decidim

This is a work in progress of the future web for Decidim project, the participatory democracy framework.

## Installation

You can set it up with [Docker](https://www.docker.com/) and [docker-compose](https://docs.docker.com/compose/).

```
docker-compose up
```

You can access to the development web with http://localhost:4567/
